package org.archcorner.pojo;

public class CustomerCampaign {
	
	private int customerCampaignId;
	
	private int campaignId;
	
	private int customerId;

	public int getCustomerCampaignId() {
		return customerCampaignId;
	}

	public void setCustomerCampaignId(int customerCampaignId) {
		this.customerCampaignId = customerCampaignId;
	}

	public int getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(int campaignId) {
		this.campaignId = campaignId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

}
