/**
 * 
 */
/**
 * @author bhagvan_kommadi
 *
 */
package org.archcorner.pojo;